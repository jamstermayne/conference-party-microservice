/**
 * PROFESSIONAL INTELLIGENCE PLATFORM - MAIN APP
 * Entry point for the revolutionary networking platform
 */

import { Store } from './store.js';
import router, { mountRouter } from './router.js';
import { api } from './services/api.js';
import { nav } from './services/nav.js';
import eventSystem, { Events } from './events.js';
import { motion } from './ui/motion.js';
import { viewTX } from './ui/viewTX.js';
import { bindPressFeedback } from './ui/press.js';
import { createFPSWatchdog } from './ui/fpsWatchdog.js';
import './ui/templates.js'; // Ensure templates are available globally
import { mountInstallFTUE } from './pwa/installFTUE.js';
import './pwa/installBonus.js'; // Self-initializing module

// Import controllers
import { HomeController } from './controllers/HomeController.js';
import { PeopleController } from './controllers/PeopleController.js';
import { OpportunitiesController } from './controllers/OpportunitiesController.js';
import { EventController } from './controllers/EventController.js';
import { MeController } from './controllers/MeController.js';
import { InviteController } from './controllers/InviteController.js';
import { CalendarController } from './controllers/CalendarController.js';
import { FomoController } from './controllers/FomoController.js';
import { AccountLinkController } from './controllers/AccountLinkController.js';
import { CalendarSyncController } from './controllers/CalendarSyncController.js';
import { InvitePanelController } from './controllers/InvitePanelController.js';

class ProfessionalIntelligenceApp {
  constructor() {
    this.initialized = false;
    this.controllers = new Map();
    this.currentController = null;
    this.signalField = null;
  }

  /**
   * Initialize the application
   */
  async init() {
    if (this.initialized) return;

    try {
      console.log('🚀 Initializing Professional Intelligence Platform...');
      
      // Initialize core systems
      await this.initializeCoreModules();
      
      // Set up routing and navigation
      this.setupRouting();
      this.setupNavigation();
      
      // Initialize UI components and FTUE
      this.initializeUI();
      this.initializeFTUE();
      
      // Set up global event listeners
      this.setupGlobalEvents();
      
      // Initialize store
      Store.init();
      
      // Default to "Tonight's Best Parties" for instant value
      const currentRoute = window.location.hash.slice(1) || '/events';
      this.navigate(currentRoute);
      
      this.initialized = true;
      console.log('✅ Professional Intelligence Platform initialized');
      
      // Add ARIA live region for status updates
      this.announcer = document.getElementById('invite-live') || this.createAnnouncer();
      
    } catch (error) {
      console.error('❌ Failed to initialize app:', error);
      this.handleInitializationError(error);
    }
  }

  /**
   * Initialize core modules
   */
  async initializeCoreModules() {
    // Test API connection
    try {
      await api.health();
      console.log('✅ API connection established');
    } catch (error) {
      console.warn('⚠️ API connection failed, continuing offline');
    }

    // Event system is auto-initialized
    console.log('✅ Event system ready');

    // Initialize motion system
    motion.setupIntersectionObservers();
    console.log('✅ Motion system initialized');
    
    // Initialize PWA install prompt
    mountInstallFTUE();
    console.log('✅ PWA install system initialized');
  }

  /**
   * Set up navigation system
   */
  setupNavigation() {
    // Wire up bottom navigation tabs
    const navTabs = document.querySelectorAll('.nav-tab[data-route]');
    navTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        const route = tab.dataset.route;
        this.navigate(route);
        this.updateActiveTab(route);
      });
    });

    // Wire up sidebar navigation (desktop)
    const sidebarItems = document.querySelectorAll('.sidebar-item[data-route]');
    sidebarItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const route = item.dataset.route;
        this.navigate(route);
        this.updateActiveSidebar(route);
      });
    });

    // Handle hash changes
    window.addEventListener('hashchange', () => {
      const route = window.location.hash.slice(2) || 'events'; // Remove #/
      this.navigate(route);
    });
  }

  /**
   * Initialize FTUE (First Time User Experience)
   */
  initializeFTUE() {
    // Initialize PWA install FTUE
    if (typeof mountInstallFTUE === 'function') {
      mountInstallFTUE();
    }

    // Set up account sheet triggers
    this.setupAccountSheet();

    // Set up calendar sync card
    this.setupCalendarSync();

    // Listen for FTUE trigger events from controllers
    Events.on('ftue:show-install', () => {
      const installCard = document.getElementById('install-ftue');
      if (installCard) {
        installCard.hidden = false;
        this.announce('Install ready.');
      }
    });

    Events.on('ftue:show-account', () => {
      this.showAccountSheet();
    });

    Events.on('ftue:show-calendar', () => {
      this.showCalendarCard();
    });
  }

  /**
   * Set up account setup sheet
   */
  setupAccountSheet() {
    const accountSheet = document.getElementById('account-sheet');
    const authButtons = accountSheet?.querySelectorAll('[data-auth]');
    
    authButtons?.forEach(button => {
      button.addEventListener('click', (e) => {
        const authProvider = e.target.dataset.auth;
        this.handleAuth(authProvider);
      });
    });
  }

  /**
   * Set up calendar sync card
   */
  setupCalendarSync() {
    const calCard = document.getElementById('cal-card');
    const calButtons = calCard?.querySelectorAll('[data-cal]');
    
    calButtons?.forEach(button => {
      button.addEventListener('click', (e) => {
        const calProvider = e.target.dataset.cal;
        this.handleCalendarSync(calProvider);
      });
    });
  }

  /**
   * Navigate to a route
   */
  navigate(route) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
      screen.style.display = 'none';
    });

    // Load the appropriate controller/content
    this.loadRoute(route);
    
    // Update navigation states
    this.updateActiveTab(route);
    this.updateActiveSidebar(route);
  }

  /**
   * Load route content
   */
  loadRoute(route) {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    // Map routes to their content
    switch (route) {
      case 'events':
        this.loadEvents();
        break;
      case 'invites':
        this.loadInvites();
        break;
      case 'home':
        this.loadHome();
        break;
      case 'people':
        this.loadPeople();
        break;
      case 'opportunities':
        this.loadOpportunities();
        break;
      case 'me':
        this.loadProfile();
        break;
      default:
        this.loadEvents(); // Default to events
    }
  }

  /**
   * Load events screen (Tonight's Best Parties)
   */
  loadEvents() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    // Use the updated EventController template with "Tonight's Best Parties"
    const eventsController = this.controllers.get('events') || new EventController();
    if (!this.controllers.has('events')) {
      this.controllers.set('events', eventsController);
    }

    // Trigger controller to render
    eventsController.mount(mainContent);
  }

  /**
   * Load invites screen (Trophy Case)
   */
  loadInvites() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    mainContent.innerHTML = `
      <section id="route-invites" class="screen">
        <header class="inv-head">
          <div>
            <h1 class="h1">Your Network</h1>
            <p class="muted">Professionals you've brought in.</p>
          </div>
          <span id="inv-pill" class="pill-gold">10 Left</span>
        </header>

        <div class="inv-stats">
          <div class="stat">
            <span class="val" id="inv-left">10</span>
            <span class="lab">Left</span>
          </div>
          <div class="stat">
            <span class="val" id="inv-red">0</span>
            <span class="lab">Redeemed</span>
          </div>
          <div class="stat">
            <span class="val" id="inv-tot">10</span>
            <span class="lab">Total Granted</span>
          </div>
        </div>

        <div class="inv-actions">
          <button class="btn btn-primary" data-action="invite">Send Invite</button>
          <button class="btn" data-action="copy">Copy Link</button>
          <button class="btn" data-action="qr">QR Code</button>
        </div>

        <h2 class="eyebrow">Recently Invited</h2>
        <ul id="inv-list" class="trophy-list" aria-live="polite"></ul>

        <!-- Bonus celebration -->
        <div id="bonus-banner" class="bonus hidden">
          <div class="confetti"></div>
          <p><b>+5 invites</b> unlocked — beautiful growth.</p>
        </div>
      </section>
    `;

    // Load sample trophy data
    this.loadTrophyData();
  }

  /**
   * Load other routes (placeholder)
   */
  loadHome() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;
    mainContent.innerHTML = '<div class="screen"><h1 class="h1">Professional Dashboard</h1><p class="sub">Coming soon...</p></div>';
  }

  loadPeople() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;
    mainContent.innerHTML = '<div class="screen"><h1 class="h1">Professional Network</h1><p class="sub">Coming soon...</p></div>';
  }

  loadOpportunities() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;
    mainContent.innerHTML = '<div class="screen"><h1 class="h1">Career Opportunities</h1><p class="sub">Coming soon...</p></div>';
  }

  loadProfile() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;
    mainContent.innerHTML = '<div class="screen"><h1 class="h1">Your Profile</h1><p class="sub">Coming soon...</p></div>';
  }

  /**
   * Load trophy data for invites
   */
  loadTrophyData() {
    const invList = document.getElementById('inv-list');
    const template = document.getElementById('tpl-invite-row');
    if (!invList || !template) return;

    // Sample data
    const trophies = [
      { name: 'Alex Chen', company: 'Epic Games', role: 'Producer', status: 'ok' },
      { name: 'Sarah Kim', company: 'Unity', role: 'Senior Dev', status: 'ok' },
      { name: 'Marcus Johnson', company: 'Riot Games', role: 'Art Director', status: 'wait' }
    ];

    trophies.forEach(trophy => {
      const clone = template.content.cloneNode(true);
      clone.querySelector('.name').textContent = trophy.name;
      clone.querySelector('.meta').textContent = `${trophy.company} • ${trophy.role}`;
      clone.querySelector('.badge').className = `badge ${trophy.status}`;
      clone.querySelector('.badge').textContent = trophy.status === 'ok' ? 'Redeemed' : 'Pending';
      invList.appendChild(clone);
    });
  }

  /**
   * Update active navigation tab
   */
  updateActiveTab(route) {
    document.querySelectorAll('.nav-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.route === route);
    });
  }

  /**
   * Update active sidebar item
   */
  updateActiveSidebar(route) {
    document.querySelectorAll('.sidebar-item').forEach(item => {
      item.classList.toggle('active', item.dataset.route === route);
    });
  }

  /**
   * Show account setup sheet
   */
  showAccountSheet() {
    const sheet = document.getElementById('account-sheet');
    if (sheet) {
      sheet.classList.add('show');
      sheet.hidden = false;
    }
  }

  /**
   * Show calendar sync card
   */
  showCalendarCard() {
    const card = document.getElementById('cal-card');
    if (card) {
      card.hidden = false;
    }
  }

  /**
   * Handle authentication
   */
  handleAuth(provider) {
    console.log(`Auth with ${provider}`);
    this.announce(`Connecting with ${provider}...`);
    
    // Hide sheet after auth
    setTimeout(() => {
      const sheet = document.getElementById('account-sheet');
      if (sheet) {
        sheet.classList.remove('show');
        sheet.hidden = true;
      }
      this.announce('Account connected.');
    }, 1500);
  }

  /**
   * Handle calendar sync
   */
  handleCalendarSync(provider) {
    console.log(`Calendar sync with ${provider}`);
    const status = document.getElementById('cal-status');
    const card = document.getElementById('cal-card');
    const success = document.getElementById('cal-success');
    
    if (status) {
      status.hidden = false;
    }
    
    setTimeout(() => {
      if (card) card.hidden = true;
      if (success) success.hidden = false;
      if (status) status.hidden = true;
      this.announce('Calendar synced — meetings will auto-match.');
    }, 2000);
  }

  /**
   * Create ARIA announcer if it doesn't exist
   */
  createAnnouncer() {
    const announcer = document.createElement('div');
    announcer.id = 'announcer';
    announcer.className = 'sr-only';
    announcer.setAttribute('aria-live', 'polite');
    announcer.setAttribute('aria-atomic', 'true');
    document.body.appendChild(announcer);
    return announcer;
  }

  /**
   * Announce message to screen readers
   */
  announce(message) {
    if (this.announcer) {
      this.announcer.textContent = message;
    }
  }

  /**
   * Set up application routing
   */
  setupRouting() {
    // Define controller map with imported classes
    const controllerMap = {
      home: HomeController,
      people: PeopleController,
      opportunities: OpportunitiesController,
      events: EventController,
      me: MeController,
      invite: InviteController,
      calendar: CalendarController,
      fomo: FomoController,
      'account-link': AccountLinkController,
      'calendar-sync': CalendarSyncController,
      invites: InvitePanelController
    };

    // Initialize controllers based on data-route attributes
    document.querySelectorAll('[data-route]').forEach(async (section) => {
      const routeName = section.dataset.route;
      if (controllerMap[routeName]) {
        try {
          const ControllerClass = controllerMap[routeName];
          const controller = new ControllerClass(section);
          await controller.init();
          this.controllers.set(routeName, controller);
          console.log(`✅ ${routeName} controller loaded`);
        } catch (error) {
          console.error(`❌ Failed to load ${routeName} controller:`, error);
        }
      }
    });

    // Define routes
    router.routes({
      '/': () => router.navigate('/home'),
      '/home': () => this.loadController('home'),
      '/people': () => this.loadController('people'),
      '/opportunities': () => this.loadController('opportunities'),
      '/events': () => this.loadController('events'),
      '/events/:id': () => this.loadController('events'),
      '/me': () => this.loadController('me'),
      '/invite': () => this.loadController('invite'),
      '/calendar': () => this.loadController('calendar')
    });

    // Set up navigation hooks
    router.beforeEach(async (to, from) => {
      // Update page title
      this.updatePageTitle(to.route);
      
      // Update navigation state
      nav.setActiveRoute(to.route);
      
      // Show loading if needed
      if (to.route !== '/home') {
        store.actions.showLoading();
      }
      
      return true;
    });

    router.afterEach(async (to) => {
      // Hide loading
      store.actions.hideLoading();
      
      // Initialize view animations
      const viewName = to.route.split('/')[1] || 'home';
      motion.initializeView(viewName);
      
      // Track navigation
      this.trackNavigation(to);
    });

    // Handle route not found
    router.notFound((path) => {
      console.warn('Route not found:', path);
      router.navigate('/home');
    });
  }

  /**
   * Initialize UI components
   */
  initializeUI() {
    // Initialize view transition system
    viewTX.init();
    
    // Initialize press feedback system
    bindPressFeedback();
    
    // Initialize performance monitoring
    createFPSWatchdog({ minFps: 45, sampleMs: 1000 });
    
    // Set up topbar interactions
    this.setupTopbar();
    
    // Set up tabbar interactions  
    this.setupTabbar();
    
    // Initialize signal field canvas
    this.initializeSignalField();
    
    // Set up quick actions
    this.setupQuickActions();
    
    // Set up theme handling
    this.setupThemeHandling();
  }

  /**
   * Set up global event listeners
   */
  setupGlobalEvents() {
    // Handle app state changes
    Store.subscribe('ui.modal', (modal) => {
      if (modal) {
        this.showModal(modal);
      } else {
        this.hideModal();
      }
    });

    Store.subscribe('ui.notification', (notification) => {
      if (notification) {
        this.showNotification(notification);
      }
    });

    Store.subscribe('ui.error', (error) => {
      if (error) {
        this.showError(error);
      }
    });

    // Handle online/offline status
    window.addEventListener('online', () => {
      Store.actions.showNotification('🟢 Back online');
      this.syncData();
    });

    window.addEventListener('offline', () => {
      Store.actions.showNotification('🔴 Working offline');
    });

    // Handle visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.handleAppResume();
      } else {
        this.handleAppPause();
      }
    });

    // Handle PWA install prompt
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      Store.patch('ui.installPrompt', e);
    });

    // Global action handler
    document.addEventListener('click', (e) => {
      const actionElement = e.target.closest('[data-action]');
      if (actionElement) {
        e.preventDefault();
        this.handleAction(actionElement.dataset.action, actionElement);
      }
    });
  }

  /**
   * Set up topbar
   */
  setupTopbar() {
    const primaryCta = document.getElementById('primary-cta');
    if (primaryCta) {
      primaryCta.addEventListener('click', () => {
        this.handlePrimaryCTA();
      });
    }
  }

  /**
   * Set up tabbar navigation
   */
  setupTabbar() {
    const tablinks = document.querySelectorAll('.tablink');
    tablinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const href = link.getAttribute('href');
        if (href) {
          const route = href.replace('#', '');
          router.navigate(route);
        }
      });
    });
  }

  /**
   * Initialize signal field canvas
   */
  initializeSignalField() {
    const canvas = document.getElementById('signal-field');
    if (!canvas) return;

    // Import and initialize canvas field
    import('./ui/canvasField.js').then(({ canvasField }) => {
      this.signalField = canvasField;
      this.signalField.init(canvas);
      console.log('✅ Signal field initialized');
    }).catch(error => {
      console.warn('⚠️ Failed to initialize signal field:', error);
    });
  }

  /**
   * Set up quick actions
   */
  setupQuickActions() {
    // Action handlers will be set up via event delegation
    // in the global event listener above
  }

  /**
   * Set up theme handling
   */
  setupThemeHandling() {
    // Apply stored theme
    const theme = Store.get('ui.theme') || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    
    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', (e) => {
      if (Store.get('ui.theme') === 'auto') {
        const newTheme = e.matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', newTheme);
      }
    });
  }

  /**
   * Load and initialize controller
   */
  async loadController(controllerName) {
    try {
      // Get existing controller or load new one
      let controller = this.controllers.get(controllerName);
      
      if (!controller) {
        console.warn(`Controller ${controllerName} not found in cache, loading...`);
        return;
      }

      // Cleanup previous controller
      if (this.currentController && this.currentController !== controller) {
        if (typeof this.currentController.destroy === 'function') {
          this.currentController.destroy();
        }
      }

      // Initialize new controller
      if (typeof controller.init === 'function') {
        await controller.init();
      }

      this.currentController = controller;
      console.log(`✅ Controller ${controllerName} initialized`);
      
    } catch (error) {
      console.error(`❌ Failed to load controller ${controllerName}:`, error);
      // Fallback to home
      if (controllerName !== 'home') {
        router.navigate('/home');
      }
    }
  }

  /**
   * Handle global actions
   */
  async handleAction(action, element) {
    const [module, method] = action.split('.');
    
    switch (module) {
      case 'invite':
        await this.handleInviteAction(method, element);
        break;
      case 'event':
        await this.handleEventAction(method, element);
        break;
      case 'presence':
        await this.handlePresenceAction(method, element);
        break;
      case 'opportunity':
        await this.handleOpportunityAction(method, element);
        break;
      case 'profile':
        await this.handleProfileAction(method, element);
        break;
      default:
        console.warn('Unknown action:', action);
    }
  }

  /**
   * Handle invite actions
   */
  async handleInviteAction(method, element) {
    switch (method) {
      case 'open':
        Store.actions.openModal({
          type: 'invite',
          data: {
            code: Store.get('invites.myCode'),
            remaining: Store.get('invites.left')
          }
        });
        break;
      case 'send':
        // Handle invite sending
        break;
    }
  }

  /**
   * Handle event actions
   */
  async handleEventAction(method, element) {
    switch (method) {
      case 'create':
        router.navigate('/events/create');
        break;
      case 'join':
        const eventId = element.dataset.eventId;
        if (eventId) {
          await api.swipeEvent(eventId, 'right');
          Store.actions.showNotification('Event saved! 🎉');
        }
        break;
    }
  }

  /**
   * Handle presence actions
   */
  async handlePresenceAction(method, element) {
    switch (method) {
      case 'edit':
        Store.actions.openModal({
          type: 'presence',
          data: Store.get('proximity')
        });
        break;
    }
  }

  /**
   * Handle primary CTA based on current route
   */
  handlePrimaryCTA() {
    const currentRoute = router.currentRoute?.route || '/home';
    
    switch (currentRoute) {
      case '/home':
        this.handleAction('invite.open');
        break;
      case '/people':
        router.navigate('/opportunities');
        break;
      case '/opportunities':
        this.handleAction('opportunity.create');
        break;
      case '/events':
        this.handleAction('event.create');
        break;
      case '/me':
        Store.actions.openModal({ type: 'settings' });
        break;
    }
  }

  /**
   * Update page title based on route
   */
  updatePageTitle(route) {
    const titleElement = document.getElementById('page-title');
    const primaryCta = document.getElementById('primary-cta');
    
    const routeConfig = {
      '/home': { title: 'Now', cta: 'Invite' },
      '/people': { title: 'People', cta: 'Next' },
      '/opportunities': { title: 'Opportunities', cta: 'Create' },
      '/events': { title: 'Events', cta: 'Add' },
      '/me': { title: 'Profile', cta: 'Settings' }
    };
    
    const config = routeConfig[route] || { title: 'PI', cta: 'Action' };
    
    if (titleElement) {
      titleElement.textContent = config.title;
      motion.animate(titleElement, {
        opacity: [0.5, 1],
        transform: ['translateY(5px)', 'translateY(0)']
      }, { duration: 300 });
    }
    
    if (primaryCta) {
      primaryCta.textContent = config.cta;
    }
  }

  /**
   * Show modal
   */
  showModal(modal) {
    // Modal implementation will be handled by individual controllers
    // This is a placeholder for global modal coordination
    Events.emit('modal:show', modal);
  }

  /**
   * Hide modal
   */
  hideModal() {
    Events.emit('modal:hide');
  }

  /**
   * Show notification
   */
  showNotification(notification) {
    // Create notification element
    const notif = document.createElement('div');
    notif.className = 'notification';
    notif.textContent = typeof notification === 'string' ? notification : notification.message;
    notif.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: var(--color-brand-primary);
      color: white;
      padding: 16px 24px;
      border-radius: 12px;
      z-index: var(--z-notification);
      transform: translateX(100%);
      transition: transform 0.3s ease;
    `;
    
    document.body.appendChild(notif);
    
    // Animate in
    setTimeout(() => {
      notif.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove
    setTimeout(() => {
      notif.style.transform = 'translateX(100%)';
      setTimeout(() => notif.remove(), 300);
    }, 3000);
  }

  /**
   * Show error
   */
  showError(error) {
    this.showNotification(`❌ ${error}`);
  }

  /**
   * Handle app resume
   */
  handleAppResume() {
    // Sync data when app comes back to focus
    this.syncData();
    
    // Resume proximity if enabled
    const proximity = Store.get('proximity.enabled');
    if (proximity) {
      import('./services/proximity.js').then(({ proximity }) => {
        proximity.startTracking();
      });
    }
  }

  /**
   * Handle app pause
   */
  handleAppPause() {
    // Pause non-critical background tasks
    if (this.signalField) {
      this.signalField.pause();
    }
  }

  /**
   * Sync data with server
   */
  async syncData() {
    try {
      const lastSync = Store.get('cache.lastSync') || 0;
      const syncData = await api.syncData(lastSync);
      
      if (syncData && syncData.updates) {
        // Apply updates to store
        Object.entries(syncData.updates).forEach(([key, value]) => {
          Store.patch(key, value);
        });
        
        Store.patch('cache.lastSync', Date.now());
        console.log('✅ Data synchronized');
      }
    } catch (error) {
      console.warn('⚠️ Sync failed:', error);
    }
  }

  /**
   * Track navigation for analytics
   */
  trackNavigation(to) {
    // Simple analytics tracking
    if (window.gtag) {
      gtag('config', 'GA_MEASUREMENT_ID', {
        page_path: to.path
      });
    }
    
    // Track in store for internal analytics
    const history = Store.get('analytics.navigation') || [];
    history.push({
      path: to.path,
      timestamp: Date.now(),
      params: to.params
    });
    
    // Keep only last 50 navigation events
    if (history.length > 50) {
      history.shift();
    }
    
    Store.patch('analytics.navigation', history);
  }

  /**
   * Handle initialization errors
   */
  handleInitializationError(error) {
    document.body.innerHTML = `
      <div style="
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        padding: 2rem;
        text-align: center;
        background: var(--color-neutral-900);
        color: white;
      ">
        <h1>⚠️ Initialization Error</h1>
        <p>The Professional Intelligence Platform failed to start.</p>
        <button onclick="window.location.reload()" style="
          padding: 12px 24px;
          background: var(--color-brand-primary);
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          margin-top: 1rem;
        ">Retry</button>
        <details style="margin-top: 2rem; max-width: 500px;">
          <summary>Technical Details</summary>
          <pre style="text-align: left; overflow: auto; margin-top: 1rem;">
${error.stack || error.message}
          </pre>
        </details>
      </div>
    `;
  }

  /**
   * Cleanup on app destroy
   */
  destroy() {
    if (this.signalField) {
      this.signalField.destroy();
    }
    
    motion.cleanup();
    router.disconnectWebSocket?.();
    this.initialized = false;
  }
}

// Initialize app when DOM is ready
const app = new ProfessionalIntelligenceApp();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => app.init());
} else {
  app.init();
}

// Export for debugging
window.app = app;
window.router = router;
window.store = Store;

// Sidebar/mobilenav
const sidenav = document.getElementById('sidenav');
const overlay = document.getElementById('overlay');
document.getElementById('menu')?.addEventListener('click', ()=>{ sidenav.classList.add('open'); overlay.hidden=false; });
overlay?.addEventListener('click', ()=>{ sidenav.classList.remove('open'); overlay.hidden=true; });

document.querySelectorAll('.nav-item').forEach(b=>{
  b.addEventListener('click', ()=>{ location.hash = '#/' + b.dataset.route; sidenav.classList.remove('open'); overlay.hidden=true; });
});

window.addEventListener('hashchange', syncNavFromRoute);
syncNavFromRoute();
function syncNavFromRoute(){
  const r = (location.hash.replace('#/','') || 'events');
  document.querySelectorAll('.nav-item').forEach(b=> b.classList.toggle('active', b.dataset.route===r));
  const t = document.getElementById('page-title'); if (t) t.textContent = r.replace(/-/g,' ').replace(/\b\w/g,m=>m.toUpperCase());
}

export default app;